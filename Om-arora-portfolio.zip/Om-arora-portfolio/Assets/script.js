AOS.init({
    duration: 1000,
    once: true
});

const themeBtn = document.getElementById("themeSwitch");

themeBtn.addEventListener("click", () => {
    const body = document.body;
    const currentTheme = body.getAttribute("data-theme");

    const newTheme = currentTheme === "light" ? "dark" : "light";
    body.setAttribute("data-theme", newTheme);

    themeBtn.innerHTML =
        newTheme === "light"
            ? '<i class="fas fa-moon"></i>'
            : '<i class="fas fa-sun"></i>';
});